# Wish-Her
A demo website, which can be used to which someone special on special occasions like birthday, anniversaries etc

# Directions
This is a open source webpage collection. You can fork it and make changes as per your need.
Please don't use it for commercial purposes.

Finally, This project is live at https://haxonicofficial.github.io/Wish-Her/

# Fork it  |  Star it  
Re-use it but please give credits :)

# Contribute
You can help me to modify this project by mapping custom-data-entries to a Restful-API like data.json. Make a new branch and perform pull-request. If it will be worthy, i'll add it to master-branch

# NOTE - 
GitHub server doesnt allow JavaScript to load directly, So go to the right end of URL and click on "Load-Unsafe-Scripts".


# Follow me  
LinkedIn  - https://www.linkedin.com/in/haxonic/

GitHub    - https://github.com/HaxonicOfficial

Facebook  - https://www.facebook.com/Haxonic1337

Instagram - https://www.instagram.com/haxonic7/

